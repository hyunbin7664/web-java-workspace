package kr.co.movmov.mapper;

import java.util.List;

import kr.co.movmov.vo.Genre;

public interface GenreMapper {
	List<Genre> getAllGenres();
}
